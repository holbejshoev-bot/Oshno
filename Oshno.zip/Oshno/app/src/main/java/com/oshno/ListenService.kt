package com.oshno

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import kotlin.concurrent.thread

/**
 * Фоновая служба Ошно: слушает микрофон офлайн, реагирует на слово «Ошно».
 * «Ошно, позвони маме» — одной фразой, или «Ошно» → пауза → команда (8 секунд).
 */
class ListenService : Service(), RecognitionListener {

    companion object {
        @Volatile var running = false
        /** (сообщение, выход из приложения) — для показа на экране, если он открыт */
        @Volatile var events: ((String, Boolean) -> Unit)? = null

        private const val CHANNEL = "oshno"
        private const val AWAKE_MS = 8000L

        // Vosk не знает слова «Ошно», поэтому ловим похожие варианты: ошно, ошна, о шно, ашно, осно…
        private val wake = Regex("(^|\\s)(о\\s)?[ао]шн\\w*|(^|\\s)осно\\w*")
    }

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var awakeUntil = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundNotification()
        if (!running) {
            running = true
            post("Загрузка…")
            thread { loadAndStart() }
        }
        return START_STICKY
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Ошно", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Ошно слушает")
            .setContentText("Скажите «Ошно, позвони …»")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun loadAndStart() {
        try {
            val dir = File(filesDir, "model-ru")
            val marker = File(dir, ".ok")
            if (!marker.exists()) {
                dir.deleteRecursively()
                copyAsset("model-ru", dir)
                marker.writeText("ok")
            }
            val m = Model(dir.absolutePath)
            model = m
            main.post {
                if (!running) return@post
                speech = SpeechService(Recognizer(m, 16000f), 16000f).also { it.startListening(this) }
                post("Слушаю. Скажите «Ошно, позвони …»")
            }
        } catch (e: Exception) {
            post("Нет модели в assets/model-ru (см. README)")
            main.post { stopSelf() }
        }
    }

    private fun copyAsset(path: String, target: File) {
        val children = assets.list(path) ?: emptyArray()
        if (children.isNotEmpty()) {
            target.mkdirs()
            children.forEach { copyAsset("$path/$it", File(target, it)) }
            return
        }
        try {
            assets.open(path).use { input ->
                target.parentFile?.mkdirs()
                FileOutputStream(target).use { input.copyTo(it) }
            }
        } catch (e: IOException) {
            target.mkdirs()
        }
    }

    private fun post(msg: String, exit: Boolean = false) {
        main.post { events?.invoke(msg, exit) }
    }

    override fun onResult(hypothesis: String?) {
        val text = try {
            JSONObject(hypothesis ?: return).optString("text")
        } catch (e: Exception) {
            return
        }
        if (text.isBlank()) return
        val t = text.lowercase()
        val now = System.currentTimeMillis()
        val hasWake = wake.containsMatchIn(t)
        if (!hasWake && now > awakeUntil) return // обычный разговор рядом — игнорируем

        val cmd = wake.replace(t, " ").trim()
        if (cmd.isEmpty()) {
            awakeUntil = now + AWAKE_MS
            post("Слушаю команду…")
            return
        }
        awakeUntil = 0
        val result = Commands.run(this, cmd)
        post("«$cmd» → ${result.message}", result.exit)
        if (result.exit) stopSelf()
    }

    override fun onPartialResult(hypothesis: String?) {}
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(e: Exception?) { post("Ошибка: ${e?.message}") }
    override fun onTimeout() {}

    override fun onDestroy() {
        running = false
        speech?.stop()
        speech?.shutdown()
        speech = null
        model?.close()
        model = null
        post("Остановлено")
        super.onDestroy()
    }
}
