package com.oshno

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.telecom.TelecomManager

/** Разбор и выполнение голосовых команд. Не зависит от экрана — работает из службы. */
object Commands {

    data class Result(val message: String, val exit: Boolean = false)

    private fun has(t: String, vararg keys: String) = keys.any { t.contains(it) }

    fun run(ctx: Context, text: String): Result {
        val t = text.lowercase().trim()
        return when {
            has(t, "выключи приложение", "выключить приложение", "закрой приложение", "закройся", "выход") ->
                Result("Выключаюсь", exit = true)
            has(t, "включи звонок", "включить звонок", "включи звук") -> Result(setRinger(ctx, true))
            has(t, "выключи звонок", "выключить звонок", "отключи звонок", "без звука") -> Result(setRinger(ctx, false))
            else -> Result(call(ctx, t))
        }
    }

    private fun setRinger(ctx: Context, on: Boolean): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            am.ringerMode = if (on) AudioManager.RINGER_MODE_NORMAL else AudioManager.RINGER_MODE_SILENT
        } catch (e: SecurityException) {
            am.ringerMode = if (on) AudioManager.RINGER_MODE_NORMAL else AudioManager.RINGER_MODE_VIBRATE
        }
        return if (on) "Звонок включён" else "Звонок выключен"
    }

    private fun call(ctx: Context, t: String): String {
        val verbs = setOf("позвони", "позвонить", "набери", "вызови", "звонок")
        val words = t.split(" ").filter { it.isNotBlank() }
        val i = words.indexOfFirst { it in verbs }
        if (i < 0) return "Не понял команду: «$t»"
        val name = words.drop(i + 1).filter { it != "пожалуйста" }
        if (name.isEmpty()) return "Кому звонить?"
        val (contactName, number) = findContact(ctx, name)
            ?: return "Контакт «${name.joinToString(" ")}» не найден"
        return try {
            val telecom = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            telecom.placeCall(Uri.fromParts("tel", number, null), Bundle())
            "Звоню: $contactName"
        } catch (e: SecurityException) {
            try {
                ctx.startActivity(
                    Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                "Звоню: $contactName"
            } catch (e2: Exception) {
                "Нет разрешения на звонки"
            }
        }
    }

    private fun stem(w: String) = when {
        w.length > 4 -> w.dropLast(2)
        w.length > 3 -> w.dropLast(1)
        else -> w
    }

    /** Поиск контакта с учётом падежей («маме» → «Мама»). */
    private fun findContact(ctx: Context, query: List<String>): Pair<String, String>? {
        val q = query.map { stem(it) }
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val number = c.getString(1) ?: continue
                    val nameWords = name.lowercase().split(" ")
                    if (q.all { s -> nameWords.any { it.startsWith(s) } }) return name to number
                }
            }
        } catch (e: SecurityException) {
        }
        return null
    }
}
