package com.oshno

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Экран Ошно: включает/выключает фоновую службу и показывает, что услышано. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var button: Button

    private val permissions: Array<String>
        get() = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            add(Manifest.permission.CALL_PHONE)
            add(Manifest.permission.READ_CONTACTS)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (permissions.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(permissions, 1)
        } else if (!ListenService.running) {
            startAssistant()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            if (!ListenService.running) startAssistant()
        } else {
            status.text = "Нужен доступ к микрофону"
        }
    }

    override fun onStart() {
        super.onStart()
        ListenService.events = { msg, exit ->
            status.text = msg
            refreshButton()
            if (exit) finishAndRemoveTask()
        }
        refreshButton()
        if (ListenService.running && status.text == "Загрузка…") status.text = "Слушаю. Скажите «Ошно, позвони …»"
    }

    override fun onStop() {
        ListenService.events = null
        super.onStop()
    }

    private fun startAssistant() {
        startForegroundService(Intent(this, ListenService::class.java))
        status.text = "Загрузка…"
        refreshButton()
    }

    private fun stopAssistant() {
        stopService(Intent(this, ListenService::class.java))
        status.text = "Остановлено"
        refreshButton()
    }

    private fun refreshButton() {
        button.text = if (ListenService.running) "Выключить Ошно" else "Включить Ошно"
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0F1115"))
            setPadding(48, 48, 48, 48)
        }
        val title = TextView(this).apply {
            text = "Ошно"
            textSize = 44f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Готов"
            textSize = 18f
            setTextColor(Color.parseColor("#7CE0A3"))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 48)
        }
        button = Button(this).apply {
            textSize = 20f
            setOnClickListener { if (ListenService.running) stopAssistant() else startAssistant() }
        }
        val hint = TextView(this).apply {
            text = "Скажите «Ошно», затем команду:\n«позвони маме» · «включи звонок» · «выключи звонок» · «выключи приложение»"
            textSize = 14f
            setTextColor(Color.parseColor("#5C6573"))
            gravity = Gravity.CENTER
            setPadding(0, 48, 0, 0)
        }
        listOf(title, status, button, hint).forEach { root.addView(it) }
        setContentView(root)
        refreshButton()
    }
}
